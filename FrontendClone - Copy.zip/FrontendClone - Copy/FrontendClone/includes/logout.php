<?php
session_start();
include 'auth.php';

// Log out the user
logout();

// Redirect to login page
header('Location: ../index.php');
exit;
