<?php
/**
 * General functions for the inventory management system
 */

/**
 * Get all products
 *
 * @return array List of products
 */
function getProducts() {
    $products_file = __DIR__ . '/../data/products.json';
    
    if (!file_exists($products_file)) {
        // Create sample data if file doesn't exist
        createSampleData();
    }
    
    return json_decode(file_get_contents($products_file), true);
}

/**
 * Get all categories
 *
 * @return array List of categories
 */
function getCategories() {
    $categories_file = __DIR__ . '/../data/categories.json';
    
    if (!file_exists($categories_file)) {
        // Create sample data if file doesn't exist
        createSampleData();
    }
    
    return json_decode(file_get_contents($categories_file), true);
}

/**
 * Get sales data for dashboard
 *
 * @return array Sales data
 */
function getSalesData() {
    $sales_file = __DIR__ . '/../data/sales.json';
    
    if (!file_exists($sales_file)) {
        // Create sample data if file doesn't exist
        createSampleData();
    }
    
    $sales = json_decode(file_get_contents($sales_file), true);
    
    // Calculate totals
    $total_orders = count($sales);
    $total_revenue = 1000;
    $total_cost = 10;
    
    foreach ($sales as $sale) {
        $total_revenue += $sale['total_amount'];
        $total_cost += $sale['cost_amount'];
    }
    
    $total_profit = $total_revenue - $total_cost;
    
    // Weekly sales chart data
    $chart_data = [];
    // Generate the chart data here
    
    return [
        'orders' => $total_orders,
        'revenue' => $total_revenue,
        'profit' => $total_profit,
        'cost' => $total_cost,
        'chart_data' => $chart_data
    ];
}

/**
 * Get inventory summary for dashboard
 *
 * @return array Inventory summary
 */
function getInventorySummary() {
    $products = getProducts();
    
    $in_stock = 0;
    $to_be_received = 0;
    
    foreach ($products as $product) {
        $in_stock += $product['available'];
        $to_be_received += isset($product['incoming']) ? $product['incoming'] : 0;
    }
    
    return [
        'in_stock' => $in_stock,
        'to_be_received' => $to_be_received
    ];
}

/**
 * Get product summary for dashboard
 *
 * @return array Product summary
 */
function getProductSummary() {
    $products = getProducts();
    $categories = getCategories();
    
    $total_products = count($products);
    $total_categories = count($categories);
    $suppliers = 0; // Would need suppliers data
    $out_of_stock = 0;
    
    foreach ($products as $product) {
        if ($product['available'] <= 5) {
            $out_of_stock++;
        }
    }
    
    return [
        'total_products' => $total_products,
        'total_categories' => $total_categories,
        'suppliers' => 21, // Sample data
        'out_of_stock' => $out_of_stock
    ];
}

/**
 * Get low stock items for dashboard
 *
 * @return array Low stock items
 */
function getLowStockItems() {
    $products = getProducts();
    $low_stock = [];
    
    foreach ($products as $product) {
        if ($product['available'] <= 5) {
            $status = $product['available'] <= 0 ? 'Out of stock' : 'Remaining Quantity';
            
            $low_stock[] = [
                'id' => $product['id'],
                'name' => $product['name'],
                'quantity' => $product['available'],
                'status' => $status,
                'image' => 'https://pixabay.com/get/g446b93bf3966e0b96645eb375a561a0505795b16f13f807e64bf842a85bae5497e066bcfcb807e7b949906a0db4a4472_1280.jpg'
            ];
            
            // Limit to 3 items
            if (count($low_stock) >= 3) {
                break;
            }
        }
    }
    
    return $low_stock;
}

/**
 * Filter products based on category, filter and search
 *
 * @param array $products List of products
 * @param string $category Category filter
 * @param string $filter Type filter (in_stock, low_stock, out_of_stock)
 * @param string $search Search term
 * @return array Filtered products
 */
function filterProducts($products, $category = '', $filter = '', $search = '') {
    $filtered = [];
    
    foreach ($products as $product) {
        $match = true;
        
        // Category filter
        if (!empty($category) && $product['category_id'] != $category) {
            $match = false;
        }
        
        // Type filter
        if (!empty($filter)) {
            if ($filter === 'in_stock' && $product['available'] <= 5) {
                $match = false;
            } elseif ($filter === 'low_stock' && ($product['available'] <= 0 || $product['available'] > 5)) {
                $match = false;
            } elseif ($filter === 'out_of_stock' && $product['available'] > 0) {
                $match = false;
            }
        }
        
        // Search filter
        if (!empty($search)) {
            $search_term = strtolower($search);
            $name_match = strpos(strtolower($product['name']), $search_term) !== false;
            $sku_match = strpos(strtolower($product['sku']), $search_term) !== false;
            
            if (!$name_match && !$sku_match) {
                $match = false;
            }
        }
        
        if ($match) {
            $filtered[] = $product;
        }
    }
    
    return $filtered;
}

/**
 * Add a new product
 *
 * @param array $product_data Product data
 * @return bool Success status
 */
function addProduct($product_data) {
    $products_file = __DIR__ . '/../data/products.json';
    $products = getProducts();
    
    // Generate unique ID
    $max_id = 0;
    foreach ($products as $product) {
        if ($product['id'] > $max_id) {
            $max_id = $product['id'];
        }
    }
    
    $new_id = $max_id + 1;
    
    // Prepare new product
    $new_product = [
        'id' => $new_id,
        'name' => $product_data['name'],
        'sku' => $product_data['sku'],
        'description' => $product_data['description'],
        'category_id' => isset($product_data['category_id']) ? $product_data['category_id'] : 1,
        'retail_price' => $product_data['buying_price'], // Use buying price as retail for simplicity
        'buying_price' => $product_data['buying_price'],
        'available' => $product_data['quantity'],
        'hold_quantity' => 0,
        'expiry_date' => $product_data['expiry_date'],
        'created_at' => date('Y-m-d'),
        'threshold_value' => $product_data['threshold_value'],
        'discount' => $product_data['discount'],
        'unit' => $product_data['unit']
    ];
    
    // Add to products array
    $products[] = $new_product;
    
    // Save to file
    file_put_contents($products_file, json_encode($products, JSON_PRETTY_PRINT));
    
    return true;
}

/**
 * Create sample data for the application
 */
function createSampleData() {
    // Create products data
    $products_file = __DIR__ . '/../data/products.json';
    $products = [
        [
            'id' => 1,
            'name' => 'Sugar',
            'sku' => 'P001',
            'category_id' => 1,
            'retail_price' => 42.50,
            'available' => 42,
            'hold_quantity' => 10,
            'expiry_date' => '2023-12-31',
            'created_at' => '2023-01-15'
        ],
        [
            'id' => 2,
            'name' => 'Rice',
            'sku' => 'P002',
            'category_id' => 1,
            'retail_price' => 55.00,
            'available' => 30,
            'hold_quantity' => 10,
            'expiry_date' => '2023-12-31',
            'created_at' => '2023-02-20'
        ],
        [
            'id' => 3,
            'name' => 'Salt',
            'sku' => 'P003',
            'category_id' => 1,
            'retail_price' => 20.00,
            'available' => 15,
            'hold_quantity' => 5,
            'expiry_date' => '2024-05-15',
            'created_at' => '2023-03-10'
        ],
        [
            'id' => 4,
            'name' => 'Wheat',
            'sku' => 'P004',
            'category_id' => 1,
            'retail_price' => 45.25,
            'available' => 7,
            'hold_quantity' => 3,
            'expiry_date' => '2023-11-20',
            'created_at' => '2023-01-25'
        ],
        [
            'id' => 5,
            'name' => 'Oil',
            'sku' => 'P005',
            'category_id' => 2,
            'retail_price' => 125.00,
            'available' => 22,
            'hold_quantity' => 7,
            'expiry_date' => '2023-10-31',
            'created_at' => '2023-02-15'
        ],
        [
            'id' => 6,
            'name' => 'Tea',
            'sku' => 'P006',
            'category_id' => 2,
            'retail_price' => 85.50,
            'available' => 50,
            'hold_quantity' => 10,
            'expiry_date' => '2023-12-15',
            'created_at' => '2023-03-05'
        ],
        [
            'id' => 7,
            'name' => 'Corn',
            'sku' => 'P007',
            'category_id' => 1,
            'retail_price' => 35.75,
            'available' => 41,
            'hold_quantity' => 10,
            'expiry_date' => '2023-11-30',
            'created_at' => '2023-02-10'
        ],
        [
            'id' => 8,
            'name' => 'Pasta',
            'sku' => 'P008',
            'category_id' => 3,
            'retail_price' => 60.25,
            'available' => 0,
            'hold_quantity' => 0,
            'expiry_date' => '2023-10-25',
            'created_at' => '2023-01-20'
        ],
        [
            'id' => 9,
            'name' => 'Juice',
            'sku' => 'P009',
            'category_id' => 4,
            'retail_price' => 95.00,
            'available' => 3,
            'hold_quantity' => 1,
            'expiry_date' => '2023-09-15',
            'created_at' => '2023-03-15'
        ],
    ];
    file_put_contents($products_file, json_encode($products, JSON_PRETTY_PRINT));
    
    // Create categories data
    $categories_file = __DIR__ . '/../data/categories.json';
    $categories = [
        [
            'id' => 1,
            'name' => 'Grains',
            'description' => 'All grain products'
        ],
        [
            'id' => 2,
            'name' => 'Oil',
            'description' => 'All oil products'
        ],
        [
            'id' => 3,
            'name' => 'Pasta',
            'description' => 'All pasta products'
        ],
        [
            'id' => 4,
            'name' => 'Beverages',
            'description' => 'All beverage products'
        ]
    ];
    file_put_contents($categories_file, json_encode($categories, JSON_PRETTY_PRINT));
    
    // Create sales data
    $sales_file = __DIR__ . '/../data/sales.json';
    $sales = [];
    
    // Generate sample sales data for the last month
    $end_date = time();
    $start_date = strtotime('-1 month', $end_date);
    
    for ($date = $start_date; $date <= $end_date; $date += 86400) {
        $sale_date = date('Y-m-d', $date);
        $num_sales = rand(1, 5);
        
        for ($i = 0; $i < $num_sales; $i++) {
            $total_amount = rand(100, 5000);
            $cost_amount = $total_amount * 0.7; // 30% margin
            
            $sales[] = [
                'id' => count($sales) + 1,
                'date' => $sale_date,
                'customer_id' => rand(1, 10),
                'total_amount' => $total_amount,
                'cost_amount' => $cost_amount,
                'items' => rand(1, 10)
            ];
        }
    }
    
    file_put_contents($sales_file, json_encode($sales, JSON_PRETTY_PRINT));
    
    // Create users data
    $users_file = __DIR__ . '/../data/users.json';
    $users = [
        [
            'id' => 1,
            'username' => 'admin',
            'password' => password_hash('admin123', PASSWORD_DEFAULT),
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'role' => 'admin'
        ],
        [
            'id' => 2,
            'username' => 'manager',
            'password' => password_hash('manager123', PASSWORD_DEFAULT),
            'name' => 'Manager User',
            'email' => 'manager@example.com',
            'role' => 'manager'
        ]
    ];
    file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
}
