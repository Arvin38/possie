<footer class="app-footer">
    <div class="container">
        <div class="footer-content">
            <div class="copyright">
                <p>&copy; <?php echo date('Y'); ?> Inventory Management System. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>
