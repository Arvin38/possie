<header class="app-header">
    <div class="header-content">
        <div class="search-container">
            <form action="inventory.php" method="get" class="search-form">
                <div class="input-group">
                    <span class="input-group-text search-icon">
                        <i class="fas fa-search"></i>
                    </span>
                    <input type="text" class="form-control search-input" name="search" placeholder="Search product, supplier, order" aria-label="Search">
                </div>
            </form>
        </div>
        
        <div class="header-actions">
            <div class="action-icon">
                <i class="fas fa-bell"></i>
                <span class="badge bg-danger">3</span>
            </div>
            
            <div class="user-profile">
                <div class="profile-pic">
                    <img src="https://scontent.fcgy2-1.fna.fbcdn.net/v/t1.6435-9/84183489_178370536813285_6065458278333153280_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeFWKUloTI7fsa4dzLUEu-edHTnooZNwd4gdOeihk3B3iJOL7TadagAHBGGMX7aOBtGbJEQ1NQMJMryAVM1H5IG1&_nc_ohc=s4vRrQ88QtEQ7kNvwHRQCya&_nc_oc=Adkse1PKyCZXc3E5ia3eJMF1mKDQtXd3F8JYTWAozErnu_UkdNfTampkXdxm_UKjgQM&_nc_zt=23&_nc_ht=scontent.fcgy2-1.fna&_nc_gid=JhAeY-fAe63vg_6vUly6lg&oh=00_AfKyuZcZ31QPpL9gpE92ndnXBhKfHQYBpnymSKOVpU3DyQ&oe=684C3CA5" alt="User Profile">
                </div>
            </div>
        </div>
    </div>
</header>
