<?php
// Determine current page
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <a href="dashboard.php">
                <img src="https://scontent.fcgy2-2.fna.fbcdn.net/v/t1.15752-9/483155470_982149707382602_8901829380791421900_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=9f807c&_nc_eui2=AeH3UaOGhZFGD05Z8dbEq0q1BaAOj340yO4FoA6PfjTI7ov3UeA0ltbzyavb8mnbDSubrE-9Y1d_MZrN-8Yt0c8Q&_nc_ohc=kItcuo2gv1oQ7kNvwG7dC1x&_nc_oc=AdlR1kbkRp3a2buK2J8gVOU6KcbYRdEeX0ocgksoEkWLl_B5Musa5FvF6oCpFcZSJ70&_nc_zt=23&_nc_ht=scontent.fcgy2-2.fna&oh=03_Q7cD2QHGiymHdKTgiJs5Rxt8MVewJ3CTtzdC5lc_qhnWpaLZWw&oe=684C437A" alt="Inventory System Logo" class="logo-img">
                <span class="logo-text">APOSTLE</span>
            </a>
        </div>
    </div>
    
    <nav class="sidebar-nav">
        <ul class="nav-list">
            <li class="nav-item <?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            <li class="nav-item <?php echo $current_page === 'inventory.php' || $current_page === 'add_product.php' ? 'active' : ''; ?>">
                <a href="inventory.php" class="nav-link">
                    <i class="fas fa-box"></i>
                    <span>Inventory</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-users"></i>
                    <span>Suppliers</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Orders</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-store"></i>
                    <span>Manage Store</span>
                </a>
            </li>
        </ul>
        
        <div class="sidebar-divider"></div>
        
        <ul class="nav-list bottom-nav">
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="includes/logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Log Out</span>
                </a>
            </li>
        </ul>
    </nav>
</aside>
