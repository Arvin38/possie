<?php
/**
 * Authentication related functions
 */

/**
 * Authenticate user
 *
 * @param string $username The username
 * @param string $password The password
 * @return bool Authentication result
 */
function authenticate($username, $password) {
    // Load users from JSON file
    $users_file = __DIR__ . '/../data/users.json';
    
    if (!file_exists($users_file)) {
        // Create default user if file doesn't exist
        $default_users = [
            [
                'id' => 1,
                'username' => 'admin',
                'password' => password_hash('admin123', PASSWORD_DEFAULT),
                'name' => 'Admin User',
                'email' => 'admin@example.com',
                'role' => 'admin'
            ]
        ];
        
        file_put_contents($users_file, json_encode($default_users, JSON_PRETTY_PRINT));
    }
    
    $users = json_decode(file_get_contents($users_file), true);
    
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            // Check if password matches
            if (password_verify($password, $user['password'])) {
                // Set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_role'] = $user['role'];
                
                return true;
            }
            break;
        }
    }
    
    return false;
}

/**
 * Check if user is logged in
 *
 * @return bool True if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Get current user details
 *
 * @return array|null User details or null if not logged in
 */
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    $users_file = __DIR__ . '/../data/users.json';
    $users = json_decode(file_get_contents($users_file), true);
    
    foreach ($users as $user) {
        if ($user['id'] == $_SESSION['user_id']) {
            // Remove sensitive data
            unset($user['password']);
            return $user;
        }
    }
    
    return null;
}

/**
 * Log out the current user
 */
function logout() {
    // Unset all session variables
    $_SESSION = [];
    
    // If it's desired to kill the session, also delete the session cookie.
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    // Finally, destroy the session
    session_destroy();
}
