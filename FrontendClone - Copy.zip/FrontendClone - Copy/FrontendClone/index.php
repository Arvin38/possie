<?php
session_start();
include 'includes/functions.php';
include 'includes/auth.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Handle login form submission
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        if (authenticate($username, $password)) {
            // Redirect to dashboard after successful login
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Invalid username or password';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7 col-sm-9">
                <div class="login-container mt-5">
                    <div class="text-center mb-4">
                        <h2 class="login-title">Login</h2>
                        <p class="text-muted">Sign in your account</p>
                    </div>
                    
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <form method="post" action="index.php">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username:</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Username">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password:</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 mt-4 mb-4">
                            <button type="submit" class="btn btn-primary login-btn">Login</button>
                        </div>
                        
                        <div class="text-center mb-3">
                            <a href="#" class="forgot-password">I forgot my password. Click here to reset</a>
                        </div>
                        
                        <div class="social-login">
                            <div class="divider">
                                <span>or continue with</span>
                            </div>
                            
                            <div class="social-buttons my-3">
                                <a href="#" class="btn btn-outline-primary facebook-btn">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="btn btn-outline-danger google-btn">
                                    <i class="fab fa-google"></i>
                                </a>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <a href="#" class="btn btn-outline-secondary register-btn">Register New Account</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
