<?php
session_start();
include 'includes/functions.php';
include 'includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Get product data
$products = getProducts();
$categories = getCategories();

// Handle filters
$category_filter = $_GET['category'] ?? '';
$filter = $_GET['filter'] ?? '';
$search = $_GET['search'] ?? '';

// Apply filters if needed
if (!empty($category_filter) || !empty($filter) || !empty($search)) {
    $products = filterProducts($products, $category_filter, $filter, $search);
}

// Pagination
$items_per_page = 10;
$total_items = count($products);
$current_page = $_GET['page'] ?? 1;
$total_pages = ceil($total_items / $items_per_page);
$offset = ($current_page - 1) * $items_per_page;

// Get products for current page
$products_page = array_slice($products, $offset, $items_per_page);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory - Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="content-wrapper">
            <?php include 'includes/header.php'; ?>
            
            <div class="content-container">
                <h1 class="page-title">Inventory</h1>
                
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="card-title">Overall Inventory</h5>
                        </div>
                        
                        <!-- Categories Section -->
                        <div class="inventory-categories mb-4">
                            <h6 class="section-title">Categories</h6>
                            <div class="category-pills">
                                <a href="inventory.php" class="category-pill <?php echo empty($category_filter) ? 'active' : ''; ?>">All</a>
                                <?php foreach ($categories as $category): ?>
                                <a href="inventory.php?category=<?php echo urlencode($category['id']); ?>" 
                                   class="category-pill <?php echo $category_filter == $category['id'] ? 'active' : ''; ?>">
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <!-- Products Table -->
                        <div class="products-section">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="section-title">Products</h6>
                                <div class="action-buttons">
                                    <a href="add_product.php" class="btn btn-primary btn-sm">
                                        <i class="fas fa-plus"></i> Add Product
                                    </a>
                                    <div class="dropdown d-inline-block ms-2">
                                        <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" id="filtersDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="fas fa-filter"></i> Filters
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="filtersDropdown">
                                            <li><a class="dropdown-item" href="inventory.php">All</a></li>
                                            <li><a class="dropdown-item" href="inventory.php?filter=in_stock">In Stock</a></li>
                                            <li><a class="dropdown-item" href="inventory.php?filter=low_stock">Low Stock</a></li>
                                            <li><a class="dropdown-item" href="inventory.php?filter=out_of_stock">Out of Stock</a></li>
                                        </ul>
                                    </div>
                                    <a href="#" class="btn btn-outline-secondary btn-sm ms-2">
                                        <i class="fas fa-download"></i> Download all
                                    </a>
                                </div>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-hover inventory-table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>SKU</th>
                                            <th>Retail Price</th>
                                            <th>Available</th>
                                            <th>Hold Quantity</th>
                                            <th>Expiry Date</th>
                                            <th>Availability</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($products_page)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No products found.</td>
                                        </tr>
                                        <?php else: ?>
                                            <?php foreach ($products_page as $index => $product): 
                                                $rowClass = $index % 2 === 0 ? 'even-row' : 'odd-row';
                                                $availabilityClass = '';
                                                $availabilityText = '';
                                                
                                                if ($product['available'] <= 0) {
                                                    $availabilityClass = 'text-danger';
                                                    $availabilityText = 'Out of stock';
                                                } elseif ($product['available'] <= 5) {
                                                    $availabilityClass = 'text-warning';
                                                    $availabilityText = 'Low stock';
                                                } else {
                                                    $availabilityClass = 'text-success';
                                                    $availabilityText = 'In stock';
                                                }
                                            ?>
                                            <tr class="<?php echo $rowClass; ?>">
                                                <td>
                                                    <div class="product-info">
                                                        <span class="product-name"><?php echo htmlspecialchars($product['name']); ?></span>
                                                    </div>
                                                </td>
                                                <td><?php echo htmlspecialchars($product['sku']); ?></td>
                                                <td>₹<?php echo number_format($product['retail_price'], 2); ?></td>
                                                <td><?php echo $product['available']; ?> Packets</td>
                                                <td><?php echo $product['hold_quantity']; ?> Packets</td>
                                                <td><?php echo date('d/m/Y', strtotime($product['expiry_date'])); ?></td>
                                                <td><span class="<?php echo $availabilityClass; ?>"><?php echo $availabilityText; ?></span></td>
                                                <td>
                                                    <div class="actions">
                                                        <a href="#" class="text-primary me-2"><i class="fas fa-edit"></i></a>
                                                        <a href="#" class="text-danger"><i class="fas fa-trash"></i></a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Pagination -->
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div class="pagination-info">
                                    Page <?php echo $current_page; ?> of <?php echo $total_pages; ?>
                                </div>
                                
                                <nav aria-label="Products pagination">
                                    <ul class="pagination">
                                        <li class="page-item <?php echo ($current_page <= 1) ? 'disabled' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $current_page - 1; ?><?php echo !empty($category_filter) ? '&category=' . urlencode($category_filter) : ''; ?><?php echo !empty($filter) ? '&filter=' . urlencode($filter) : ''; ?>" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>
                                        
                                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                            <?php if ($i == 1 || $i == $total_pages || ($i >= $current_page - 1 && $i <= $current_page + 1)): ?>
                                                <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>">
                                                    <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty($category_filter) ? '&category=' . urlencode($category_filter) : ''; ?><?php echo !empty($filter) ? '&filter=' . urlencode($filter) : ''; ?>">
                                                        <?php echo $i; ?>
                                                    </a>
                                                </li>
                                            <?php elseif ($i == $current_page - 2 || $i == $current_page + 2): ?>
                                                <li class="page-item disabled">
                                                    <a class="page-link" href="#">...</a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                        
                                        <li class="page-item <?php echo ($current_page >= $total_pages) ? 'disabled' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $current_page + 1; ?><?php echo !empty($category_filter) ? '&category=' . urlencode($category_filter) : ''; ?><?php echo !empty($filter) ? '&filter=' . urlencode($filter) : ''; ?>" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
