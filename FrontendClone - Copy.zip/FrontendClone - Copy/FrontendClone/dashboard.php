<?php
session_start();
include 'includes/functions.php';
include 'includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Load dashboard data
$sales_data = getSalesData();
$inventory_summary = getInventorySummary();
$product_summary = getProductSummary();
$low_stock_items = getLowStockItems();

// Current period filter (default to weekly)
$period = $_GET['period'] ?? 'weekly';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="content-wrapper">
            <?php include 'includes/header.php'; ?>
            
            <div class="content-container">
                <h1 class="page-title">Dashboard</h1>
                
                <div class="row">
                    <div class="col-lg-8">
                        <!-- Sales Overview Card -->
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Sale Overview</h5>
                                <div class="row sale-overview mt-4">
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <div class="metric-icon bg-light-blue">
                                                <i class="fas fa-shopping-bag"></i>
                                            </div>
                                            <div class="metric-value">
                                                <h3><?php echo number_format($sales_data['orders']); ?></h3>
                                                <p>Sales</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <div class="metric-icon bg-light-green">
                                                <i class="fas fa-dollar-sign"></i>
                                            </div>
                                            <div class="metric-value">
                                                <h3><?php echo number_format($sales_data['revenue'], 0); ?></h3>
                                                <p>Revenue</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <div class="metric-icon bg-light-yellow">
                                                <i class="fas fa-percentage"></i>
                                            </div>
                                            <div class="metric-value">
                                                <h3><?php echo number_format($sales_data['profit']); ?></h3>
                                                <p>Profit</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <div class="metric-icon bg-light-purple">
                                                <i class="fas fa-money-bill"></i>
                                            </div>
                                            <div class="metric-value">
                                                <h3><?php echo number_format($sales_data['cost']); ?></h3>
                                                <p>Cost</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Sales & Purchase Chart -->
                                <div class="chart-container mt-5">
                                    <h5 class="chart-title">Sales & Purchase</h5>
                                    <div class="period-selector text-end mb-3">
                                        <div class="btn-group">
                                            <a href="?period=weekly" class="btn btn-sm <?php echo $period == 'weekly' ? 'btn-primary' : 'btn-outline-primary'; ?>">Weekly</a>
                                        </div>
                                    </div>
                                    <canvas id="salesChart" height="250"></canvas>
                                    
                                    <div class="chart-legend mt-3">
                                        <div class="legend-item">
                                            <span class="legend-color purchase"></span>
                                            <span>Purchase</span>
                                        </div>
                                        <div class="legend-item">
                                            <span class="legend-color sales"></span>
                                            <span>Sales</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <!-- Inventory Summary Card -->
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Inventory Summary</h5>
                                <div class="summary-stats">
                                    <div class="row mt-4">
                                        <div class="col-6">
                                            <div class="summary-item">
                                                <div class="summary-icon bg-light-orange">
                                                    <i class="fas fa-box"></i>
                                                </div>
                                                <div class="summary-info">
                                                    <h3><?php echo number_format($inventory_summary['in_stock']); ?></h3>
                                                    <p>Quantity in stock</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="summary-item">
                                                <div class="summary-icon bg-light-purple">
                                                    <i class="fas fa-truck-loading"></i>
                                                </div>
                                                <div class="summary-info">
                                                    <h3><?php echo number_format($inventory_summary['to_be_received']); ?></h3>
                                                    <p>To be received</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Product Summary -->
                                <h5 class="card-title mt-4">Product Summary</h5>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <div class="product-stat">
                                            <h3><?php echo number_format($product_summary['total_products']); ?></h3>
                                            <p>Number of products</p>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="product-stat">
                                            <h3><?php echo number_format($product_summary['total_categories']); ?></h3>
                                            <p>Number of categories</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <div class="product-stat">
                                            <h3><?php echo number_format($product_summary['suppliers']); ?></h3>
                                            <p>Number of suppliers</p>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="product-stat">
                                            <h3><?php echo number_format($product_summary['out_of_stock']); ?></h3>
                                            <p>Number of low quantity</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Low Quantity Stock -->
                                <h5 class="card-title mt-4">Low Quantity Stock</h5>
                                <div class="low-stock-list mt-3">
                                    <?php foreach ($low_stock_items as $item): ?>
                                    <div class="low-stock-item">
                                        <div class="item-info">
                                            <img src="<?php echo $item['image']; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="item-image">
                                            <div class="item-details">
                                                <h6><?php echo htmlspecialchars($item['name']); ?></h6>
                                                <p class="text-danger"><?php echo htmlspecialchars($item['status']); ?></p>
                                            </div>
                                        </div>
                                        <div class="item-quantity">
                                            <span class="badge bg-danger"><?php echo $item['quantity']; ?></span>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                    
                                    <a href="inventory.php" class="btn btn-sm btn-outline-primary mt-3">See All</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/chart.js"></script>
</body>
</html>
