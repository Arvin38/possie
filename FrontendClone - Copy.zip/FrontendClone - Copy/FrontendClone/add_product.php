<?php
session_start();
include 'includes/functions.php';
include 'includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Get categories
$categories = getCategories();

// Handle form submission
$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $_POST['product_name'] ?? '';
    $product_id = $_POST['product_id'] ?? '';
    $description = $_POST['description'] ?? '';
    $buying_price = $_POST['buying_price'] ?? '';
    $quantity = $_POST['quantity'] ?? '';
    $unit = $_POST['unit'] ?? '';
    $expiry_date = $_POST['expiry_date'] ?? '';
    $threshold_value = $_POST['threshold_value'] ?? '';
    $discount = $_POST['discount'] ?? '';
    
    // Validation
    if (empty($product_name) || empty($product_id) || empty($buying_price) || empty($quantity)) {
        $error = 'Please fill in all required fields';
    } else {
        // Add product
        $result = addProduct([
            'name' => $product_name,
            'sku' => $product_id,
            'description' => $description,
            'buying_price' => floatval($buying_price),
            'quantity' => intval($quantity),
            'unit' => $unit,
            'expiry_date' => $expiry_date,
            'threshold_value' => floatval($threshold_value),
            'discount' => floatval($discount)
        ]);
        
        if ($result) {
            $success = true;
        } else {
            $error = 'Failed to add product. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Inventory Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="app-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="content-wrapper">
            <?php include 'includes/header.php'; ?>
            
            <div class="content-container">
                <h1 class="page-title">APOSTLE</h1>
                
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="card-title">New Product</h5>
                        </div>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success">Product added successfully!</div>
                        <?php endif; ?>
                        
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <form action="add_product.php" method="post" class="add-product-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <!-- Product Image -->
                                    <div class="mb-4">
                                        <label class="form-label">Product Image</label>
                                        <div class="product-image-upload">
                                            <div class="image-preview">
                                                <i class="fas fa-image"></i>
                                                <span>Drop image here</span>
                                            </div>
                                            <div class="upload-info text-muted mt-2">
                                                <small>or</small> <a href="#" class="text-primary">browse</a> <small>to choose a file</small>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Product Name -->
                                    <div class="mb-3">
                                        <label for="product_name" class="form-label">Product Name</label>
                                        <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter product name" required>
                                    </div>
                                    
                                    <!-- Product ID -->
                                    <div class="mb-3">
                                        <label for="product_id" class="form-label">Product ID</label>
                                        <input type="text" class="form-control" id="product_id" name="product_id" placeholder="Enter product ID" required>
                                    </div>
                                    
                                    <!-- Description -->
                                    <div class="mb-3">
                                        <label for="description" class="form-label">Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="3" placeholder="Enter product description"></textarea>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <!-- Buying Price -->
                                    <div class="mb-3">
                                        <label for="buying_price" class="form-label">Buying Price</label>
                                        <input type="number" step="0.01" class="form-control" id="buying_price" name="buying_price" placeholder="Enter buying price" required>
                                    </div>
                                    
                                    <!-- Quantity -->
                                    <div class="mb-3">
                                        <label for="quantity" class="form-label">Quantity</label>
                                        <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Enter initial quantity" required>
                                    </div>
                                    
                                    <!-- Unit -->
                                    <div class="mb-3">
                                        <label for="unit" class="form-label">Unit</label>
                                        <input type="text" class="form-control" id="unit" name="unit" placeholder="Enter product unit">
                                    </div>
                                    
                                    <!-- Expiry Date -->
                                    <div class="mb-3">
                                        <label for="expiry_date" class="form-label">Expiry Date</label>
                                        <input type="date" class="form-control" id="expiry_date" name="expiry_date">
                                    </div>
                                    
                                    <!-- Threshold Value -->
                                    <div class="mb-3">
                                        <label for="threshold_value" class="form-label">Threshold Value</label>
                                        <input type="text" class="form-control" id="threshold_value" name="threshold_value" placeholder="Enter supply level">
                                    </div>
                                    
                                    <!-- Discount -->
                                    <div class="mb-3">
                                        <label for="discount" class="form-label">Discount</label>
                                        <input type="number" step="0.01" class="form-control" id="discount" name="discount" placeholder="Enter discount percentage">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-actions mt-4 d-flex justify-content-end">
                                <button type="button" class="btn btn-outline-secondary me-2" onclick="window.location.href='inventory.php'">Cancel</button>
                                <button type="submit" class="btn btn-primary">Add Product</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <script src="assets/js/main.js"></script>
</body>
</html>
