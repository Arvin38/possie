/**
 * Charts for Dashboard
 */

document.addEventListener('DOMContentLoaded', function() {
    // Sales Chart
    const salesChartCanvas = document.getElementById('salesChart');
    
    if (salesChartCanvas) {
        // Weekly sales & purchase data (example data)
        const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        
        const purchaseData = [1000, 1000, 1000, 1000, 1000, 1000, 1000];
        const salesData = [1000, 1000, 1000, 1000, 1000, 1000, 1000];
        
        new Chart(salesChartCanvas, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Purchase',
                        data: purchaseData,
                        backgroundColor: 'rgba(59, 130, 246, 0.3)',
                        borderColor: 'rgba(59, 130, 246, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Sales',
                        data: salesData,
                        backgroundColor: 'rgba(59, 130, 246, 0.7)',
                        borderColor: 'rgba(59, 130, 246, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value >= 100 ? (value / 100) + 'k' : value;
                            }
                        }
                    }
                }
            }
        });
    }
});
