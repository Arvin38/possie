/**
 * Main JavaScript for Inventory Management System
 */

document.addEventListener('DOMContentLoaded', function() {
    // Mobile sidebar toggle
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // File upload handling for product image
    const imageUpload = document.querySelector('.product-image-upload');
    
    if (imageUpload) {
        imageUpload.addEventListener('click', function() {
            // Create a hidden file input
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = 'image/*';
            fileInput.style.display = 'none';
            
            // Add to body and trigger click
            document.body.appendChild(fileInput);
            fileInput.click();
            
            // Handle file selection
            fileInput.addEventListener('change', function(e) {
                if (e.target.files && e.target.files[0]) {
                    const reader = new FileReader();
                    
                    reader.onload = function(event) {
                        // Create image preview
                        const preview = document.querySelector('.image-preview');
                        preview.innerHTML = `<img src="${event.target.result}" alt="Preview" style="max-width: 100%; max-height: 150px; border-radius: 8px;">`;
                    };
                    
                    reader.readAsDataURL(e.target.files[0]);
                }
                
                // Remove the input from the DOM
                document.body.removeChild(fileInput);
            });
        });
    }
    
    // Handle product search
    const searchInput = document.querySelector('.search-input');
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                
                // Get the search form and submit it
                const searchForm = document.querySelector('.search-form');
                searchForm.submit();
            }
        });
    }
});
